// Jogo do Jardineiro – Reflorestamento Interativo com Acessibilidade
// Desenvolvido em p5.js com foco em clareza, usabilidade e acessibilidade

let jardineiro;
let arvores = [];
let sementes = [];
let totalArvoresNecessarias = 15;
let temperatura = 25;
let energia = 100;
let maxEnergia = 100;
let qtdSementes = 3;
let tempo;
let fundoInicial, fundoFinal, corFundo;
let nivel = 1;
let frameContador = 0;
let jogoIniciado = false;
let mensagem = "";
let mensagemTimer = 0;
let emojiJardineiro;

function setup() {
  createCanvas(900, 600);
  textAlign(CENTER, CENTER);
  textSize(28);
  jardineiro = createVector(width / 2, height / 2);
  fundoInicial = color(135, 206, 250); // azul claroTente:


  fundoFinal = color(255, 69, 0); // laranja avermelhado
  tempo = 0;
  gerarSementes(5);
}

function draw() {
  if (!jogoIniciado) {
    telaInicial();
    return;
  }

  frameContador++;
  tempo += 0.0005 * nivel;
  corFundo = lerpColor(fundoInicial, fundoFinal, tempo);
  background(corFundo);

  atualizarNivel();
  moverJardineiro();
  mostrarJardineiro();
  mostrarArvores();
  mostrarSementes();
  mostrarHUD();
  verificarFimDeJogo();
  mostrarMensagemTemporaria();
}

function telaInicial() {
  background(220);
  fill(0);
  textAlign(CENTER, CENTER);
  textSize(28);
  text("🌳 Jogo do Jardineiro 🌳", width / 2, height / 3);
  textSize(18);
  text("Plante 15 árvores antes que a temperatura chegue a 40°C.", width / 2, height / 3 + 40);
  text("Setas do teclado: mover", width / 2, height / 3 + 70);
  text("P: plantar árvore", width / 2, height / 3 + 100);
  text("R: descansar (recupera energia)", width / 2, height / 3 + 130);
  text("Pressione ENTER para começar.", width / 2, height / 3 + 180);
}

function keyPressed() {
  if (!jogoIniciado && keyCode === ENTER) {
    jogoIniciado = true;
  }
  if ((key === 'p' || key === 'P') && qtdSementes > 0) {
    plantarArvore();
  }
  if (key === 'r' || key === 'R') {
    energia = maxEnergia;
    exibirMensagem("💤 Energia recuperada!");
  }
}

function atualizarNivel() {
  if (frameCount % 600 === 0) {
    nivel++;
    temperatura += 1;
    gerarSementes(int(random(1, 3)));
  }
}

function moverJardineiro() {
  let moved = false;
  if (energia > 0) {
    if (keyIsDown(LEFT_ARROW)) {
      jardineiro.x -= 4;
      moved = true;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      jardineiro.x += 4;
      moved = true;
    }
    if (keyIsDown(UP_ARROW)) {
      jardineiro.y -= 4;
      moved = true;
    }
    if (keyIsDown(DOWN_ARROW)) {
      jardineiro.y += 4;
      moved = true;
    }
  }
  if (moved) energia -= 0.2;
  energia = constrain(energia, 0, maxEnergia);

  jardineiro.x = constrain(jardineiro.x, 0, width);
  jardineiro.y = constrain(jardineiro.y, 40, height);

  coletarSementes();
}

function mostrarJardineiro() {
  textSize(24);
  text("👨‍🌾", jardineiro.x, jardineiro.y);
}

function mostrarArvores() {
  for (let arvore of arvores) {
    let tempoCrescimento = millis() - arvore.inicio;
    let fase;
    if (tempoCrescimento < 2000) {
      fase = "🌱";
    } else if (tempoCrescimento < 5000) {
      fase = "🌿";
    } else {
      fase = "🌳";
    }
    textSize(24);
    text(fase, arvore.x, arvore.y);
  }
}

function mostrarSementes() {
  for (let semente of sementes) {
    textSize(16);
    text("🌰", semente.x, semente.y);
  }
}

function plantarArvore() {
  arvores.push({ x: jardineiro.x, y: jardineiro.y, inicio: millis() });
  qtdSementes--;
  exibirMensagem("🌱 Árvore plantada!");
}

function gerarSementes(quantidade) {
  for (let i = 0; i < quantidade; i++) {
    sementes.push(createVector(random(width), random(50, height)));
  }
}

function coletarSementes() {
  for (let i = sementes.length - 1; i >= 0; i--) {
    let d = dist(jardineiro.x, jardineiro.y, sementes[i].x, sementes[i].y);
    if (d < 20) {
      qtdSementes++;
      sementes.splice(i, 1);
      exibirMensagem("🌰 Semente coletada!");
    }
  }
}

function mostrarHUD() {
  fill(255);
  rect(0, 0, width, 40);
  fill(0);
  textSize(16);
  textAlign(LEFT);
  text(`🌳 Árvores: ${arvores.length}/${totalArvoresNecessarias}`, 10, 25);
  text(`🌡️ Temp.: ${temperatura}°C`, 200, 25);
  text(`⚡ Energia: ${energia.toFixed(0)}%`, 350, 25);
  text(`🌰 Sementes: ${qtdSementes}`, 500, 25);
  text(`📈 Nível: ${nivel}`, 650, 25);
}

function verificarFimDeJogo() {
  if (arvores.length >= totalArvoresNecessarias) {
    noLoop();
    fill(0, 255, 0);
    textSize(32);
    textAlign(CENTER);
    text("Parabéns! Você reflorestou o planeta! 🎉", width / 2, height / 2);
  } else if (temperatura >= 32) {
    noLoop();
    fill(255, 0, 0);
    textSize(32);
    textAlign(CENTER);
    text("Fim de jogo! A temperatura ficou alta demais! ☠️", width / 2, height / 2);
  }
}

function exibirMensagem(txt) {
  mensagem = txt;
  mensagemTimer = 120;
}

function mostrarMensagemTemporaria() {
  if (mensagemTimer > 0) {
    fill(0);
    textSize(20);
    textAlign(CENTER);
    text(mensagem, width / 2, height - 30);
    mensagemTimer--;
  }
}
